# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for 
# educational purposes provided that (1) you do not distribute or publish 
# solutions, (2) you retain this notice, and (3) you provide clear 
# attribution to UC Berkeley, including a link to 
# http://inst.eecs.berkeley.edu/~cs188/pacman/pacman.html
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero 
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and 
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import random

from game import Directions
import util
from game import Agent


class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices)  # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"

        """
        My Observations:
        Score is directly proportional to minimum to ghost distance.
        Score is inversely proportional to minimum food distance.
        Score is directly proportional to minimum distance to capsules.
        Score is inversely proportional to minimum distance to scared ghosts.
        All of these, if combined, will be a good score to take 'action'.
        Also, it is better to reduce the priority of reflexes with Directions.STOP.
        """
        food_distances = []
        blank_adjacents = 0
        food_x = -1
        for i in newFood:
            food_x += 1
            food_y = -1
            for j in i:
                food_y += 1
                if j:
                    # Appending distances to each of the food item to food_distances list
                    food_distances.append(util.manhattanDistance(newPos, (food_x, food_y)))
                    if newFood[food_x - 1][food_y] == False and newFood[food_x + 1][food_y] == False and \
                                    newFood[food_x][food_y - 1] == False and newFood[food_x][food_y + 1] == False:
                        blank_adjacents += 1

        # Minimum of all the distances to food is used in scoring
        min_food_distance = 0 if len(food_distances) == 0 else min(food_distances)
        import sys
        # Since food distance is inversely proportional to the score, calculating the inverse of it
        inverse_food_component = 0 if len(food_distances) == 0 else 1.0/min_food_distance

        power_distances = []
        for x in successorGameState.getCapsules():
            # if util.manhattanDistance(newPos, x) < 2:
                # Distances to power capsules are added to power_distances list
                power_distances.append(util.manhattanDistance(newPos, x))

        # Minimum distance to power capsule is factored in for score calculation
        min_power_distance = 0 if len(power_distances) == 0 else min(power_distances)

        # Since power capsule distance is inversely proportional to the score, calculating the inverse of it
        inverse_power_component = 0 if min_power_distance == 0 else 1 / min_power_distance

        ghost_distances = []
        scared_ghost_distances = []
        for x in newGhostStates:
            if 0 == x.scaredTimer:
                # Considering only active ghosts which are not scared here
                ghost_distances.append(util.manhattanDistance(newPos, x.configuration.pos))
            else:
                # Considering only scared ghosts here
                scared_ghost_distances.append(util.manhattanDistance(newPos, x.configuration.pos))

        min_ghost_distance = 0 if len(ghost_distances) == 0 else min(ghost_distances)
        min_scared_ghost_distance = 0 if len(scared_ghost_distances) == 0 else min(scared_ghost_distances)

        # inverse of scared ghosts is proportional to score
        inverse_scared_ghost_component = 0 if min_scared_ghost_distance == 0 else 1 / min_scared_ghost_distance

        # Adding all the factors to the score
        score = inverse_food_component
        score += inverse_power_component
        score += inverse_scared_ghost_component

        if min_ghost_distance < 2 and action != Directions.STOP:
            # Factoring in the ghost distances
            score -= min_food_distance

        if action == Directions.STOP:
            # Reducing the score of STOP action over others
            score -= sys.maxint

        return successorGameState.getScore() + score - blank_adjacents


def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()


class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn='scoreEvaluationFunction', depth='2'):
        self.index = 0  # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

# Global variable to keep track of number of nodes expanded by each invocation of minimax_value()
num_of_nodes = 0

# Global variable to keep track of the moving sum of nodes consumed by the game.
total_nodes = 0


class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def minimax_value(self, gameState, height):
        global num_of_nodes

        # If the terminal node is reached, height will be at the limit
        if height == self.depth * gameState.getNumAgents():
            utility_value = self.evaluationFunction(gameState)
            # print utility_value
            num_of_nodes += 1
            # returning the value to be utilized by upper nodes
            return utility_value
        # Distinguishing between max and min nodes using the remainder value
        agent_num = height % gameState.getNumAgents()
        if 0 == agent_num:
            # Modulus resulting in zero always indicates max node
            actions = gameState.getLegalActions(agent_num)
            # Removing the STOP action to increase speed
            if Directions.STOP in actions:
                actions.remove(Directions.STOP)

            max_value = float("-inf")
            max_action = Directions.STOP
            if len(actions) > 0:
                for action in actions:
                    successor_state = gameState.generateSuccessor(agent_num, action)
                    # Invoking the minimax_value for successor with increased depth value
                    ret_value = self.minimax_value(successor_state, height + 1)
                    # Updating the max value and max action based on the value received
                    if ret_value > max_value:
                        max_value = ret_value
                        max_action = action
                if 0 == height:
                    num_of_nodes += 1
                    # print 'num_of_nodes: ' + str(num_of_nodes)
                    # print max_value
                    return max_action
                num_of_nodes += 1
                return max_value
            else:
                # If there are no actions, then the node acts as terminal node
                utility_value = self.evaluationFunction(gameState)
                num_of_nodes += 1
                return self.evaluationFunction(gameState)
        else:
            # Represents min node actions
            actions = gameState.getLegalActions(agent_num)

            # Avoiding STOP to increase speed
            if Directions.STOP in actions:
                actions.remove(Directions.STOP)

            min_value = float("inf")
            if len(actions) > 0:
                for action in actions:
                    successor_state = gameState.generateSuccessor(agent_num, action)
                    # Invoking minimax on successor nodes to get the value
                    ret_value = self.minimax_value(successor_state, height + 1)
                    # Updating the min value based on the result received
                    if ret_value < min_value:
                        min_value = ret_value
                num_of_nodes += 1
                return min_value
            else:
                # Considering the node as terminal since there are no actions associated with the node.
                num_of_nodes += 1
                return self.evaluationFunction(gameState)


    def getAction(self, gameState):
        global num_of_nodes
        global total_nodes
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"
        num_of_nodes = 0
        chosen_action = self.minimax_value(gameState, 0)
        total_nodes += num_of_nodes
        print 'total_nodes: ' + str(total_nodes)
        # print chosen_action
        return chosen_action


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def minimax_value(self, gameState, height, alpha, beta):
        global num_of_nodes
        # print 'self.depth: ' + str(self.depth)
        if height == self.depth  * gameState.getNumAgents():
            # Terminal Node. Return value of the state to upper nodes.
            utility_value = self.evaluationFunction(gameState)
            # print utility_value
            num_of_nodes += 1
            return utility_value

        # Distinguish between max and min nodes
        agent_num = height % gameState.getNumAgents()

        final_action = Directions.STOP
        actions = gameState.getLegalActions(agent_num)
        # Avoid STOP action to increase speed
        if Directions.STOP in actions:
            actions.remove(Directions.STOP)

        if 0 == agent_num:
            # Represents max node
            if len(actions) > 0:
                for action in actions:
                    if alpha < beta:
                        # Only process if alpha < beta. Meaning, the value derived here could change the result.
                        successor_state = gameState.generateSuccessor(agent_num, action)
                        ret_value = self.minimax_value(successor_state, height + 1, alpha, beta)
                        # Update the action based on the returned result
                        if ret_value > alpha:
                            final_action = action
                        # Since this is max node, update alpha value.
                        alpha = max(alpha, ret_value)
                if 0 == height:
                    # Finished traversal of the entire tree. Now, return the action and not the value.
                    num_of_nodes += 1
                    # print alpha
                    # exit(0)
                    return final_action
                num_of_nodes += 1
                return alpha
            else:
                # No actions for this node. Consider this to be a terminal node
                utility_value = self.evaluationFunction(gameState)
                num_of_nodes += 1
                # print 'here 1: ' + str(utility_value)
                return utility_value
        else:
            # Reached min node
            if len(actions) > 0:
                min_values = []
                for action in actions:
                    if self.depth == 3 and gameState.getNumAgents() == 2 and alpha == 10:
                        successor_state = gameState.generateSuccessor(agent_num, action)
                    if alpha < beta:
                        # Cut the unnecessary processing of trees by ensuring alpha is less than beta.
                        successor_state = gameState.generateSuccessor(agent_num, action)
                        # Update the beta value
                        beta = min(beta, self.minimax_value(successor_state, height + 1, alpha, beta))
                num_of_nodes += 1
                return beta
            else:
                # No actions pending in the node. Consider this to be a terminal node.
                utility_value = self.evaluationFunction(gameState)
                num_of_nodes += 1
                # print 'here 2: ' + str(utility_value)
                return utility_value

    def getAction(self, gameState):
        global num_of_nodes
        global total_nodes
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        "Alpha Beta Pruning"
        num_of_nodes = 0
        chosen_action = self.minimax_value(gameState, 0, float("-inf"), float("inf"))
        total_nodes += num_of_nodes
        print 'total_nodes: ' + str(total_nodes)
        return chosen_action


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()


def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction


class ContestAgent(MultiAgentSearchAgent):
    """
      Your agent for the mini-contest
    """

    def getAction(self, gameState):
        """
          Returns an action.  You can use any method you want and search to any depth you want.
          Just remember that the mini-contest is timed, so you have to trade off speed and computation.

          Ghosts don't behave randomly anymore, but they aren't perfect either -- they'll usually
          just make a beeline straight towards Pacman (or away from him if they're scared!)
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

